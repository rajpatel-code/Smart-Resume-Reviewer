import os
from typing import Optional
from openai import OpenAI

class LLMClient:
    def __init__(self):
        self.api_key = os.getenv("OPENAI_API_KEY")
        self.model = os.getenv("LLM_MODEL", "gpt-4o-mini")
        self.client = None
        if self.api_key:
            try:
                self.client = OpenAI(api_key=self.api_key)
            except Exception:
                self.client = None

    def available(self) -> bool:
        return self.client is not None

    def generate(self, prompt: str, temperature: float = 0.2, max_tokens: int = 1200) -> Optional[str]:
        if not self.available():
            return None
        try:
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role":"system","content":"You are a concise, helpful CV reviewer."},
                          {"role":"user","content":prompt}],
                temperature=temperature,
                max_tokens=max_tokens,
            )
            return resp.choices[0].message.content
        except Exception:
            return None
