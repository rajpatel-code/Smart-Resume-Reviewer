from collections import Counter
from typing import Dict, List, Tuple
import re

DEFAULT_ROLE_KEYWORDS = {
    "data scientist": [
        "python","pandas","numpy","scikit-learn","ml","machine learning",
        "deep learning","tensorflow","pytorch","sql","statistics",
        "feature engineering","model deployment","nlp","time series"
    ],
    "product manager": [
        "roadmap","user research","stakeholders","kpis","metrics","prioritization",
        "go-to-market","a/b testing","analytics","sql","jira","agile","scrum",
        "wireframes","market analysis"
    ],
    "software engineer": [
        "python","java","c++","git","docker","kubernetes","microservices",
        "system design","rest api","testing","ci/cd","cloud","aws","gcp","azure"
    ]
}

def normalize_tokens(text: str) -> List[str]:
    toks = re.findall(r"[a-zA-Z][a-zA-Z\-\+\.#0-9]*", (text or "").lower())
    return toks

def extract_keywords_from_jd(jd_text: str, target_role: str) -> List[str]:
    """
    Pull keywords from JD if provided; otherwise fall back to role defaults.
    """
    if jd_text and jd_text.strip():
        toks = normalize_tokens(jd_text)
        # Heuristic: include frequent nouns/skills-like tokens
        counts = Counter(toks)
        # Keep top 40 unique tokens after filtering trivial words
        stop = set(["and","or","the","a","an","to","of","in","with","for","on","at","by",
                    "is","are","be","as","that","from","this","you","we","they","our",
                    "will","have","has","it","your","us","their","not","can","may",
                    "requirements","responsibilities","preferred","must","experience",
                    "skills","years","team","work","ability","strong","excellent"])
        keywords = [w for w,_ in counts.most_common(200) if w not in stop and len(w) > 2]
        # Deduplicate while preserving order
        seen = set()
        filtered = []
        for k in keywords:
            if k not in seen:
                seen.add(k)
                filtered.append(k)
        return filtered[:40]

    # Fallback to role defaults
    role = (target_role or "").lower().strip()
    return DEFAULT_ROLE_KEYWORDS.get(role, DEFAULT_ROLE_KEYWORDS["software engineer"])

def score_resume_against_jd(resume_text: str, jd_keywords: List[str]) -> Tuple[Dict, List[str], List[str]]:
    """
    Simple keyword coverage and density scoring.
    """
    resume_toks = normalize_tokens(resume_text)
    resume_set = set(resume_toks)
    found = sorted(set(k for k in jd_keywords if k in resume_set))
    missing = sorted(set(k for k in jd_keywords if k not in resume_set))

    coverage = len(found) / max(1, len(set(jd_keywords)))
    density = sum(resume_toks.count(k) for k in found) / max(1, len(resume_toks))

    scores = {
        "keyword_coverage": round(coverage, 3),
        "keyword_density": round(density, 3),
        "found_keyword_count": len(found),
        "missing_keyword_count": len(missing),
    }
    return scores, found, missing
