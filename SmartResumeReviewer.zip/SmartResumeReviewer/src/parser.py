from typing import IO
import fitz  # PyMuPDF
import re

def extract_text_from_pdf(file: IO[bytes]) -> str:
    """
    Extracts text from a PDF file-like object using PyMuPDF.
    """
    text = []
    with fitz.open(stream=file.read(), filetype="pdf") as doc:
        for page in doc:
            text.append(page.get_text("text"))
    return "\n".join(text)

def normalize_text(text: str) -> str:
    """
    Basic cleanup for better downstream processing.
    """
    if not text:
        return ""
    # Collapse multiple spaces/newlines
    text = re.sub(r'\r', '\n', text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = re.sub(r'[ \t]{2,}', ' ', text)
    return text.strip()
