from io import BytesIO
from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
import textwrap

def export_txt(text: str) -> bytes:
    return text.encode("utf-8")

def export_feedback_pdf(feedback: dict, target_role: str) -> bytes:
    """
    Very simple PDF export of feedback using reportlab.
    """
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=LETTER)
    width, height = LETTER
    x_margin = 0.8 * inch
    y = height - 1.0 * inch

    def draw_wrapped(text, max_chars=95, leading=14):
        nonlocal y
        for line in textwrap.wrap(text, width=max_chars):
            c.drawString(x_margin, y, line)
            y -= leading

    title = f"Smart Resume Reviewer — Feedback ({target_role})"
    c.setFont("Helvetica-Bold", 14)
    draw_wrapped(title, max_chars=70, leading=18)
    y -= 6

    c.setFont("Helvetica", 10)

    if "summary" in feedback:
        c.setFont("Helvetica-Bold", 11)
        draw_wrapped("Summary:", max_chars=85, leading=14)
        c.setFont("Helvetica", 10)
        draw_wrapped(str(feedback["summary"]), max_chars=95, leading=12)
        y -= 8

    sections = feedback.get("sections", {})
    if isinstance(sections, dict):
        for sec, content in sections.items():
            if y < 1.2*inch:
                c.showPage()
                y = height - 1.0*inch
                c.setFont("Helvetica", 10)
            c.setFont("Helvetica-Bold", 11)
            draw_wrapped(f"{sec}:", max_chars=85, leading=14)
            c.setFont("Helvetica", 10)
            if isinstance(content, list):
                for item in content:
                    draw_wrapped(f"• {item}", max_chars=95, leading=12)
            elif isinstance(content, dict):
                for k, v in content.items():
                    draw_wrapped(f"{k}:", max_chars=85, leading=12)
                    if isinstance(v, list):
                        for item in v:
                            draw_wrapped(f"  - {item}", max_chars=95, leading=12)
                    else:
                        draw_wrapped(f"  {v}", max_chars=95, leading=12)
            else:
                draw_wrapped(str(content), max_chars=95, leading=12)
            y -= 6

    for field in ("quick_wins", "tailoring_tips", "notes"):
        if field in feedback:
            if y < 1.2*inch:
                c.showPage()
                y = height - 1.0*inch
                c.setFont("Helvetica", 10)
            c.setFont("Helvetica-Bold", 11)
            draw_wrapped(field.replace("_"," ").title() + ":", max_chars=85, leading=14)
            c.setFont("Helvetica", 10)
            items = feedback[field]
            if isinstance(items, list):
                for item in items:
                    draw_wrapped(f"• {item}", max_chars=95, leading=12)
            else:
                draw_wrapped(str(items), max_chars=95, leading=12)
            y -= 6

    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer.getvalue()
