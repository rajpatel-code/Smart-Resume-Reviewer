import json
from typing import Dict, List
from .llm import LLMClient

RULE_BASED_TIPS = {
    "structure": [
        "Use clear section headers: Summary, Experience, Education, Skills.",
        "Keep to 1 page (early career) or 2 pages (experienced).",
        "Use consistent date formats and alignment."
    ],
    "content": [
        "Begin bullets with strong action verbs (Built, Led, Shipped).",
        "Quantify impact (e.g., 'reduced latency by 30%').",
        "Tailor achievements to the target role and JD keywords."
    ],
    "tone": [
        "Be specific and factual; avoid buzzwords with no evidence.",
        "Keep first-person pronouns to a minimum.",
        "Prefer active voice and concise sentences."
    ],
    "formatting": [
        "Use a clean, readable font; maintain consistent spacing.",
        "Limit colors and graphics to avoid ATS parsing issues.",
        "Use bullet points for achievements; avoid dense paragraphs."
    ]
}

def _rule_based_feedback(resume_text: str, jd_keywords: List[str], scores: Dict) -> Dict:
    missing = scores.get("missing_keyword_count", 0)
    fb = {
        "summary": "Rule-based feedback generated without an LLM.",
        "sections": {
            "Structure": RULE_BASED_TIPS["structure"],
            "Content": RULE_BASED_TIPS["content"],
            "Tone": RULE_BASED_TIPS["tone"],
            "Formatting": RULE_BASED_TIPS["formatting"],
            "Keywords": {
                "advice": "Incorporate missing or weakly represented keywords naturally into bullet points.",
                "suggested_keywords": jd_keywords[:15]
            }
        },
        "notes": [
            f"Keyword coverage: {scores.get('keyword_coverage',0):.0%}.",
            "Consider aligning job titles and achievements with the target role."
        ]
    }
    if missing > 0:
        fb["notes"].append("Some important keywords are missing; add them where truthful.")
    return fb

def build_feedback(
    resume_text: str,
    target_role: str,
    jd_text: str,
    jd_keywords: List[str],
    scores: Dict,
    use_llm: bool,
    model: str,
    temperature: float,
    max_tokens: int,
) -> Dict:
    client = LLMClient() if use_llm else None
    if client and client.available():
        prompt = f"""
You are reviewing a resume for the role: {target_role}.
Job Description (may be empty):
---
{jd_text or 'N/A'}
---

Resume:
---
{resume_text[:12000]}
---

Provide JSON with fields:
- summary (2-4 sentences)
- sections: {{
    "Education": [advice...],
    "Experience": [advice...],
    "Skills": [advice...],
    "Projects": [advice...],
    "Tone": [advice...],
    "Formatting": [advice...],
    "Keywords": {{
        "missing": [list],
        "nice_to_have": [list]
    }}
}}
- quick_wins: [5-7 bullet edits that have big impact]
- tailoring_tips: [how to align to the JD/role]
Make it **specific** and **actionable**. Keep it concise.
"""
        out = client.generate(prompt, temperature=temperature, max_tokens=max_tokens)
        if out:
            try:
                return json.loads(out)
            except Exception:
                # If model returned text not JSON, wrap it
                return {"summary":"LLM returned non-JSON text.", "raw": out}

    # Fallback
    return _rule_based_feedback(resume_text, jd_keywords, scores)

def build_improved_resume(
    resume_text: str,
    target_role: str,
    jd_text: str,
    use_llm: bool,
    model: str,
    temperature: float,
    max_tokens: int,
) -> str:
    client = LLMClient() if use_llm else None
    if client and client.available():
        prompt = f"""
Rewrite the following resume to better target the role "{target_role}".
Use crisp bullets (max 6 per role), quantify impact, and weave in relevant JD keywords naturally.
Keep layout ATS-friendly (no tables). Return plain text only.

Job Description (may be empty):
---
{jd_text or 'N/A'}
---

Resume:
---
{resume_text[:12000]}
---
"""
        out = client.generate(prompt, temperature=temperature, max_tokens=max_tokens)
        if out:
            return out

    # Fallback: simple header + original content
    header = f"TARGET ROLE: {target_role}\n\nSUMMARY:\nResults-oriented professional. Tailor with measurable impact statements.\n\n"
    return header + resume_text
